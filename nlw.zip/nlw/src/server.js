// criar servidor
const express = require("express")
const server = express()


// pegar o BD
const db = require("./database/db")



// Configurar pasta publica
server.use(express.static("public"))



//habilitar o uso do req.body na nossa aplicação
server.use(express.urlencoded({ extended: true}))



// Utilizando template engine
const nunjucks = require("nunjucks")
nunjucks.configure("src/views", {
    express: server,
    noCache: true
})




/* 
    Configurar caminhos da minha aplicação '/'
    Pagina inicial
    req: Requisição
    res: Resposta
*/
server.get("/", (req,res) => {
    //res.sendFile(__dirname + "/views/index.html")
    // usando nunjucks
    return res.render("index.html")
})




// confg. caminho da app, create-point
server.get("/create-point", (req,res) => {

    //req.query: Query String da nossa url
    // elementos (dados), que apacerem na url


    //res.sendFile(__dirname + "/views/create-point.html")
    // usando nunjucks
    return res.render("create-point.html")
})


server.post("/savepoint", (req, res) => {

    // req.body: O corpo do nosso formulario
    
    // Inserir dados no BD
    // 2 Inserir dados na tabela
    const query = `
        INSERT INTO places (
            image,
            name,
            address,
            address2,
            state,
            city,
            items
        ) VALUES (?,?,?,?,?,?,?);
    `

    const values = [
        req.body.image,
        req.body.name,
        req.body.address,
        req.body.address2,
        req.body.state,
        req.body.city,
        req.body.items
    ]


    function afterInsertData(err) {
        // caso exista erro
        if (err) {
            console.log(err)
            return res.send("Erro no Cadastro")
        }
        // se não tiver erro, faça
        console.log("Cadastrado com Sucesso")
        console.log(this)

        return res.render("create-point.html", {saved: true})
    }

    db.run(query, values, afterInsertData)

    
})



// confg. caminho da app, search
server.get("/search", (req,res) => {


    // configurando barra de pesquisa
    const search = req.query.search

    if (search == "") {
        // pesquisa vazia
        // mostrar a página html com os dados do BD
    return res.render("search-results.html", {total:0})

    }




    // pegar dados do banco de dados
    // 3 Consultar os dados da tabela

    db.all(`SELECT * FROM places WHERE city LIKE '%${search}%'`, function(err, rows){
        // caso exista erro
        if (err) {
            return console.log(err)
        }

        // contar quatos elementos tem dentro do arrey (ROWS)
        const total = rows.length

        // se não tiver erro, faça
        // usando nunjucks
        // mostrar a página html com os dados do BD
    return res.render("search-results.html", {places: rows, total:total})

    })


    
})




// ligar o servidor
server.listen(3030)

