/*  CRIAR BANCO DE DADOS SQLITE
    Configurando Banco de Dados */

// importar a dependencia do sqlite3
const sqlite3 = require("sqlite3").verbose()


//criar o objeto que ira fazer a opc no BD
const db = new sqlite3.Database("./src/database/database.db")



// exportar o obj db
module.exports = db



//    'serialize' roda um sequencia de codigos 
// utilizar o obj de BD, para nossas opc

//db.serialize(() => {
    /*  com comandos SQL irei:   */
/*
    // 1 Criar uma tabela
    db.run(`
        CREATE TABLE IF NOT EXISTS places (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            image TEXT,
            name TEXT,
            address TEXT,
            address2 TEXT,
            state TEXT,
            city TEXT,
            items TEXT
        );
    `)

    // 2 Inserir dados na tabela
    const query = `
        INSERT INTO places (
            image,
            name,
            address,
            address2,
            state,
            city,
            items
        ) VALUES (?,?,?,?,?,?,?);
    `

    const values = [
        "https://images.unsplash.com/photo-1567393528677-d6adae7d4a0a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80",
        "Papersider",
        "Guilherme Gemballa, Jardim América",
        "Número 260",
        "Santa Catarina",
        "Rio do Sul",
        "Resíduos Eletrônicosm Lâmpadas"
    ]


    function afterInsertData(err) {
        // caso exista erro
        if (err) {
            return console.log(err)
        }
        // se não tiver erro, faça
        console.log("Cadastrado com Sucesso")
        console.log(this)
    }

    db.run(query, values, afterInsertData)
*/
/*
    // 3 Consultar os dados da tabela

    db.all(`SELECT * FROM places`, function(err, rows){
        // caso exista erro
        if (err) {
            return console.log(err)
        }

        // se não tiver erro, faça
        console.log("Aqui estão seus registros")
        console.log(rows)

    } )
*/
    // 4 Deletar um dado da tabela
    /*
    db.run(`DELETE FROM places WHERE id = ?`, [4], function(err) {
        // caso exista erro
        if (err) {
            return console.log(err)
        }

        // se não tiver erro, faça
        console.log("Registro deletado com sucesso!")
    })
    */

//})






