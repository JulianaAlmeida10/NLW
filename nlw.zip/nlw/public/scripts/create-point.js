// função 
function populateUFs(){
    const ufSelect = document.querySelector("select[name=uf]") 

    // fetch é uma promessa (ir no link, se vai trazer algo é outra historia)
    fetch("https://servicodados.ibge.gov.br/api/v1/localidades/estados")
    .then( (res) => { return res.json()}) //função anonima q esta retornando um valor    ou   .then( res => res.json())
    .then( states => {

        for( const state of states) {
            ufSelect.innerHTML += `<option value="${state.id}">${state.nome}</option>`
        }

    })
}

//https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome

populateUFs()





function getCities(event) {
    const citySelect = document.querySelector("select[name=city]") 
    const stateInput = document.querySelector("input[name=state]")

    const ufValue = event.target.value


    const indexOfSelectedState = event.target.selectedIndex 
    stateInput.value = event.target.options[indexOfSelectedState].text

    const url = `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${ufValue}/municipios`
    

    citySelect.innerHTML = "<option value>Selecione a Cidade</option>"
    citySelect.disabled = true


    fetch(url)
    .then( res => res.json() ) 
    .then( cities => {


        for( const city of cities) {
            citySelect.innerHTML += `<option value="${city.nome}">${city.nome}</option>`
        }

        // abilitando o seletor da cidade
        citySelect.disabled = false

    })

}




//esta procurando um elemento no documento
document.
    querySelector("select[name=uf]")   
    .addEventListener("change", getCities) //fica ouvindo um evento







const collectedItems = document.querySelector("input[name=items]")





// Itens de coleta
// pegar todos os li's
const itemsToCollect = document.querySelectorAll(".itens-grid li")


// para cada um deles, faça
for( const item of itemsToCollect){
    item.addEventListener("click", handleSelectedItem)
}


// quais são os itens selecionados
let selectedItems = []


// função
function handleSelectedItem(event){


    const itemLi = event.target

    // add ou remover uma classe com javaScript
    itemLi.classList.toggle("selected") // 'toggle' add e remove o selected


    const itemId = itemLi.dataset.id  //esta pegando o 'id' das imagens 1,2,3,4,5,6




    /* verificar se existem itens selecionados, se sim
    pegar os itens selecionados */
    const alreadySelected = selectedItems.findIndex( item => {
        const itemFound = item == itemId //isso sera true ou false
        return itemFound
    }) //já foi selecionado





    /* se já estiver selecionado, tirar da seleção */
    if (alreadySelected >= 0) {
        // remover da seleção
        const filteredItems = selectedItems.filter( item => {
            const itemDifferent = item != itemId  // false
            return itemDifferent
        })


        selectedItems = filteredItems
    /* se não estiver selecionado, adicionar a seleção */
    }else{   
        selectedItems.push(itemId) //'push' add em um arrey
    }


   /* atualizar o campo escodido com os itens selecionados */
   collectedItems.value = selectedItems








}